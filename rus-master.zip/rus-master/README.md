# **68 TOOLS TERMUX**
# **Create: 2017**
# **update: 2019 versi 6.8**
# **----------------------**

# INSTALL DI TERMUX:
# $ pkg install bash
# $ pkg install python2
# $ pkg install git
# $ git clone https://github.com/Rusmana-ID/rus
# $ cd rus
# $ sh v2.sh

# **----------------------**
# **Jika sudah masuk silahkan pilih nomor 1 dulu untuk mendowdload username dan pasword nya jika**
# **sudah tau username dan pasword nya kalian pilih nomor 2 lalu silahkan login**

# **Setelah itu kalian pilih no 3 untuk beri bintang github admin**
# **Jika sdh kalian pilih no 1 untuk install bahan2 nya jika gk di install bahan2 nya**
# **tools nya gk bakalan bisa di pakai atau akan terjadi error**

# **Lalu jika sdh kalian pilih nomor 2 untuk menjalankan tols nya**
# **dan Selamat menggunakan dan gunakan dengan bijak ya**
z



