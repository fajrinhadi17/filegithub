######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Febry, Bima, Accil, Alfa           #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest, Zhum Bai Lee          #
######################################
z="
";Jz='33;1';lz='CEBO';Wz='p="\';pz='b}╚═';Az='a="\';dz='════';Tz='[37;';Fz='31;1';Pz='\033';Yz='hi="';Xz='39;1';Lz='34;1';Qz='[36;';Hz='32;1';iz='N AC';Cz='30;1';cz='m}╔═';Zz='[40;';Vz='[38;';Mz='c="\';Nz='35;1';Gz='h="\';Oz='pu="';gz='${h}';Rz='1m"';Ez='m="\';mz='OK  ';Bz='033[';fz='m}║ ';qz='╝"';hz='LOGI';nz='${b}';kz='T FA';oz='║"';ez='╗"';bz=' "${';Iz='k="\';Sz='p1="';Kz='b="\';Dz='m"';az='echo';Uz='m1="';jz='COUN';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Pz$Tz$Rz$z$Uz$Pz$Vz$Rz$z$Wz$Bz$Xz$Dz$z$Yz$Pz$Zz$Rz$z$az$bz$cz$dz$dz$dz$dz$dz$dz$ez$z$az$bz$fz$gz$hz$iz$jz$kz$lz$mz$nz$oz$z$az$bz$pz$dz$dz$dz$dz$dz$dz$qz" 