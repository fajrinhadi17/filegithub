######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Febry, Bima, Accil, Alfa           #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest, Zhum Bai Lee          #
######################################
z="
";iBz='╝${h';RBz='{m}╔';gBz=' ╩ "';cCz='uh"';Qz='[36;';cBz=' ═╩╝';jCz='}>"';az='clea';Uz='m1="';hz='m} ║';VBz='  ║ ';tBz='b} ╚';xz='╠═╣╚';GCz='{b}▐';HCz='█${m';Bz='033[';EBz='═╝╚═';SCz=':${b';sz='b}╔═';fz='____';GBz='b} ║';FCz='┈┈█$';rz='╗"';dBz='╚═╝╩';dz=' "${';QCz='} Au';wBz='b}═╝';iz='${m}';VCz='!0n"';Gz='h="\';PCz='█${p';JCz='p}.｡';UCz='Tr3v';rBz='book';Kz='b="\';OBz='m}╔═';RCz='thor';KBz='╔═╗╦';ez='m} _';fCz='═══$';gz='___"';Rz='1m"';Dz='m"';YCz='}Bla';Nz='35;1';BCz='╩╩╩╩';lBz='╚╝${';aBz='{m}╚';IBz='██${';hBz='m}╚═';TBz='  ║║';xBz='b}  ';WCz='  ╚═';Lz='34;1';Zz='[40;';ZCz='ck C';Xz='39;1';pBz='nan ';ABz='b}╚═';iCz='═${p';KCz='oO"';Yz='hi="';bz='r';Hz='32;1';XBz=' ║ "';kBz='{h}█';mBz='${p}';CCz='╩╝"';Pz='\033';Az='a="\';fBz='╝╚═╝';mz='m}║$';ZBz='╔╝${';Jz='33;1';yBz='╚╗║$';gCz='{p}X';bBz='╗║${';hCz='${k}';vz='${h}';lz='m}║"';YBz='{k}╬';eBz='═╝╩═';Cz='30;1';LCz=' ║${';OCz=' ╚╗$';Iz='k="\';oz=' ╔╦╗';MCz='h}██';NBz='╔╦╗"';pz='╔═╗╔';Fz='31;1';WBz=' ║╣ ';eCz='{k}═';kz='▒▒${';sBz='"';XCz='Team';oBz='tema';UBz='║╣ ║';jz='▒▒▒▒';NCz='╠╦╦╦';Tz='[37;';SBz='{b}║';nz='{h} ';CBz=' ╩ ╩';PBz='═╗${';bCz=' Crs';QBz='h}█$';Sz='p1="';Wz='p="\';dCz='p}<$';TCz='}Mr.';ICz='}▒${';DBz='╩ ╩╚';yz='═╗╚═';tz='════';DCz=' ║║$';cz='echo';vBz='}███';Ez='m="\';BBz='═══╝';qz='═╗╔═';uz='═══╗';Vz='[38;';HBz='████';qBz='Face';nBz=' Per';wz=' ║║║';LBz='  ╦ ';MBz=' ╔═╗';aCz='oder';Oz='pu="';uBz='╗${h';ACz='{m}╠';JBz='b}╚╗';FBz='╝"';Mz='c="\';jBz='}█${';ECz='{h}┈';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Pz$Tz$Rz$z$Uz$Pz$Vz$Rz$z$Wz$Bz$Xz$Dz$z$Yz$Pz$Zz$Rz$z$az$bz$z$cz$dz$ez$fz$fz$gz$z$cz$dz$hz$iz$jz$jz$kz$lz$z$cz$dz$hz$iz$jz$jz$kz$lz$z$cz$dz$hz$iz$jz$jz$kz$mz$nz$oz$pz$qz$rz$z$cz$dz$sz$tz$tz$uz$vz$wz$xz$yz$rz$z$cz$dz$ABz$tz$tz$BBz$vz$CBz$DBz$EBz$FBz$z$cz$dz$GBz$vz$HBz$HBz$IBz$JBz$vz$oz$KBz$LBz$MBz$NBz$z$cz$dz$GBz$vz$IBz$OBz$PBz$QBz$RBz$PBz$QBz$SBz$vz$TBz$UBz$VBz$WBz$XBz$z$cz$dz$GBz$vz$IBz$mz$YBz$iz$ZBz$QBz$aBz$bBz$QBz$SBz$vz$cBz$dBz$eBz$fBz$gBz$z$cz$dz$GBz$vz$IBz$hBz$iBz$jBz$mz$kBz$iz$lBz$QBz$SBz$mBz$nBz$oBz$pBz$qBz$rBz$sBz$z$cz$dz$tBz$uBz$vBz$HBz$IBz$wBz$sBz$z$cz$dz$xBz$yBz$ACz$BCz$CCz$z$cz$dz$xBz$DCz$ECz$FCz$GCz$HBz$HCz$ICz$JCz$KCz$z$cz$dz$xBz$LCz$MCz$iz$NCz$rz$z$cz$dz$xBz$OCz$kBz$HBz$PCz$QCz$RCz$iz$SCz$TCz$UCz$VCz$z$cz$dz$xBz$WCz$BBz$mBz$XCz$iz$SCz$YCz$ZCz$aCz$bCz$cCz$z$cz$dz$dCz$eCz$tz$tz$tz$fCz$gCz$hCz$tz$tz$tz$tz$iCz$jCz$z$cz" 
