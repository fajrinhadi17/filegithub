<?php
include 'ip.php';
header('Location: forwarding_link/index.html');
exit
?>
