<?php

/**
 * Created by PhpStorm.
 * User: jaredchu
 * Date: 3/30/17
 * Time: 10:57 PM
 */

namespace JC\Firebase\Enums;

class PrintType
{
    const PRETTY = 'pretty';
    const SILENT = 'silent';
}