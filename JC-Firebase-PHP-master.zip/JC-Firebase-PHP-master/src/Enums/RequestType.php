<?php

/**
 * Created by PhpStorm.
 * User: jaredchu
 * Date: 3/30/17
 * Time: 10:54 PM
 */

namespace JC\Firebase\Enums;

use JC\HttpClient\Enums\Method;

class RequestType extends Method
{
}